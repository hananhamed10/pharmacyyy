﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace pharmacy.Migrations
{
    /// <inheritdoc />
    public partial class MakeCustomerNameRequired : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
